# mpp-frontend-v1

Original site files for [MPP](https://multiplayerpiano.com). These files are not up to date and are left as-is from Brandon's last addition to the site.

This repository contains the latest official site files given to us by Brandon Lockaby, the creator of Multiplayer Piano. He no longer owns the site, but these files were made by him and we were given his permission to share it explicitly with the world under the GPL license before new changes are made to the site.
